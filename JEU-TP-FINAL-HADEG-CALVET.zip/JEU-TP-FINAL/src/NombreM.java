import java.util.Scanner;


public class NombreM {

	private int[] nombreM ;//tableau pour stocker le nombre 
	
	private int nbTentative ;
	private int tentativeMax ;
	
	private boolean perdu ;
	
	public NombreM() {
		// TODO Auto-generated constructor stub
		this.nombreM = new int [4];//remplissage du tableau 
		nombreM[0] = (int)(Math.random() * 10);
		nombreM[1] = (int)(Math.random() * 10);
		nombreM[2] = (int)(Math.random() * 10);
		nombreM[3] = (int)(Math.random() * 10);
		
		this.nbTentative = 0;
		
		this.tentativeMax = 10;
		
		this.perdu = true;
		
		
	}

	public NombreM(int chiffre) {
		
		this.nombreM = new int [4];
		nombreM[3] = (chiffre%10);
		nombreM[2] = ((chiffre/10)%10);
		nombreM[1] = (((chiffre/10)/10)%10);
		nombreM[0] = ((((chiffre/10)/10)/10)%10);
		
		this.nbTentative = 0;
		
		this.tentativeMax = 10;
		
		this.perdu = true;
		
		}
	
	private void affichage() {//bien afficher les chiffres
		
		System.out.println(String.valueOf(this.nombreM[0]) +String.valueOf(this.nombreM[1]) + String.valueOf(this.nombreM[2])+String.valueOf(this.nombreM[3]));
		
	}

	
	public void AffiRep(int chiffre) {
		String reponse = "";
		
		
		
		if(chiffre%10 == nombreM[3]) {
			
			reponse = "=" ; 
		
			
		}else if(chiffre%10 < nombreM[3]){
			
			reponse = "+" ;
			
		}else {
			
			reponse = "-" ;
			
		}
		
		
		if((chiffre/10)%10 == nombreM[2]) {
			
			reponse =  "=" + reponse ; 
		}else if((chiffre/10)%10 < nombreM[2]){
			
			reponse =  "+" + reponse;
			
		}else {
			
			reponse =  "-" + reponse;
			
		}
		
		
		if(((chiffre/10)/10)%10 == nombreM[1]) {
			
			reponse =  "=" + reponse; 
		}else if(((chiffre/10)/10)%10 < nombreM[1]){
			
			reponse =  "+"+ reponse ;
			
		}else {
			
			reponse = "-" + reponse;
			
		}
		
		if((((chiffre/10)/10)/10)%10 == nombreM[0]) {
			
			reponse = "=" + reponse ; 
			
		}else if((((chiffre/10)/10)/10)%10 < nombreM[0]){
			
			reponse = "+" + reponse ;
			
		}else {
			
			reponse =  "-" + reponse ;
			
		}
		
		System.out.println(reponse);
		
	}
	

	public boolean comparaison(int chiffre) {
		String reponse = "";
		
		int cpt = 0;
		
		if(chiffre%10 == nombreM[3]) {
			
			reponse = "=" ; 
			cpt++;
			
		}else if(chiffre%10 < nombreM[3]){
			
			reponse = "+" ;
			
		}else {
			
			reponse = "-" ;
			
		}
		
		
		if((chiffre/10)%10 == nombreM[2]) {
			
			reponse =  "=" + reponse ; 
			cpt++;
		}else if((chiffre/10)%10 < nombreM[2]){
			
			reponse =  "+" + reponse;
			
		}else {
			
			reponse =  "-" + reponse;
			
		}
		
		
		if(((chiffre/10)/10)%10 == nombreM[1]) {
			
			reponse =  "=" + reponse; 
			cpt++;
		}else if(((chiffre/10)/10)%10 < nombreM[1]){
			
			reponse =  "+"+ reponse ;
			
		}else {
			
			reponse = "-" + reponse;
			
		}
		
		if((((chiffre/10)/10)/10)%10 == nombreM[0]) {
			
			reponse = "=" + reponse ; 
			cpt++;
		}else if((((chiffre/10)/10)/10)%10 < nombreM[0]){
			
			reponse = "+" + reponse ;
			
		}else {
			
			reponse =  "-" + reponse ;
			
		}
		
		if(cpt == 4) {
			return true;
		}
		
		return false;
		
	}
	
	private boolean chiffOk(int chiffre) {
		
		int n1,n2,n3,n4,n5;
		
		n1 = (((chiffre/10)/10)/10)%10 ;
		n2 = ((chiffre/10)/10)%10 ; 
		n3 = (chiffre/10)%10 ; 
		n4 = chiffre%10 ; 
		
		n5 = ((((chiffre/10)/10)/10))/10 %10 ;
		
		String test = String.valueOf(n1) + String.valueOf(n2) + String.valueOf(n3) + String.valueOf(n4) ;

		if (n1 > 9 || n2 > 9 || n3 > 9 || n4 > 9  || n5 != 0) {
			return true;
		}
		
		if (n1 < 0 || n2 < 0 || n3 < 0 || n4 < 0  ) {
			return true;
		}
		
		if(chiffre == Integer.valueOf(test))
			return false;
		
		return false;

	}
	
	public void traitement() {
		
		
		while(nbTentative < tentativeMax) {
			
			System.out.println("Vous etes a votre "+ this.nbTentative + "eme tentative, Entrez un chiffre : ");
			
			Scanner in = new Scanner(System.in);
			
			int chiffre = in.nextInt();
			
			while(chiffOk(chiffre)) {
				System.out.println("Erreur format");
				chiffre = in.nextInt();
			}
			
			
			
			if(comparaison(chiffre)) {
				
				System.out.println("bravo ta trouver en "+nbTentative+" tentatives !");
				nbTentative = tentativeMax;
				perdu = false;
				
			}else {
				AffiRep(chiffre);
			}
			
			
			nbTentative++;
			
		}
		
		if(perdu) {
			System.out.print("Perdu ! Le nombre mystere etait :");
			affichage();
		}
		 
		System.out.println("Rejouer ? (tapez 1)");
		System.out.println("Retour au menu ? (tapez 2)");
		System.out.println("Quittez le jeu ? (tapez 3)");
		
		Scanner ina = new Scanner(System.in);
		
		int choix = ina.nextInt();
		
		if(choix == 1) {
			NombreM j = new NombreM();
			j.traitement();
		}
		
		if(choix == 2) {
			Menu restart = new Menu();
			restart.start();
		}
		
		if(choix == 3) {
			System.exit(0);
		}
		
	}

	public void traitementDeux() {
		
		int cpt = 0;
		int n1 = 0,n2 = 0,n3 = 0,n4 = 0;
			
		while(nbTentative < tentativeMax) {
			
			if(cpt==0) {
				
				n1 = (int) (Math.random() * 10); //5
				n2 = (int) (Math.random() * 10); //6
				n3 = (int) (Math.random() * 10); //4
				n4 = (int) (Math.random() * 10); //3
				cpt++;
				
			}else {
				//8888
				String ch = String.valueOf(n1) + String.valueOf(n2) + String.valueOf(n3) + String.valueOf(n4) ;
				// "5643"
				int cho = Integer.valueOf(ch) ;
				// 5643
				System.out.println(ch);
				
				if(comparaison(cho)) {
					
					System.out.println("bravo ta trouver en "+nbTentative+" tentatives !");
					nbTentative = tentativeMax;
					perdu = false;
					
				}else {
					AffiRep(cho);
				}
				
				
				// ++++
				if(n1 < nombreM[0]) {
					
					n1 = (n1+1) + (int) ( Math.random() * ( ( 9 - (n1 + 1) ) + 1 ) );
					
				}else if(n1 == nombreM[0]) {
					
				}else if(n1 > nombreM[0]) {
					n1 = (int) ( Math.random() *  n1 );
				}
				
				if(n2 < nombreM[1]) {
					
					n2 = (n2+1) + (int) ( Math.random() * ( ( 9 - (n2 + 1) ) + 1 ) );
					
				}else if(n2 == nombreM[1]) {
					
				}else if(n2 > nombreM[1]) {
					n2 = (int) ( Math.random() *  n2 );
				}
				
				if(n3 < nombreM[2]) {
					
					n3 = (n3+1) + (int) ( Math.random() * ( ( 9 - (n3 + 1) ) + 1 ) );
					
				}else if(n3 == nombreM[2]) {
					
				}else if(n3 > nombreM[2]) {
					n3 = (int) ( Math.random() *  n3 );
				}
				
				if(n4 < nombreM[3]) {
					
					n4 = (n4+1) + (int) ( Math.random() * ( ( 9 - (n4 + 1) ) + 1 ) );
					
				}else if(n4 == nombreM[3]) {
					
				}else if(n4 > nombreM[3]) {
					n4 = (int) ( Math.random() *  n4 );
				}
				
				
			}
			
			
			System.out.println(nbTentative);
			nbTentative++;
		}
		
		if(perdu) {
			System.out.print("Perdu ! Le nombre mystere etait :");
			affichage();
		}
		
		System.out.println("Rejouer ? (tapez 1)");
		System.out.println("Retour au menu ? (tapez 2)");
		System.out.println("Quittez le jeu ? (tapez 3)");
		
		Scanner ina = new Scanner(System.in);
		
		int choix = ina.nextInt();
		
		if(choix == 1) {
			System.out.println("Ouais donne moi un nombre a 4 chiffres");

			Scanner inaa = new Scanner(System.in);

			int chiffre = inaa.nextInt();



			NombreM a = new NombreM(chiffre);

			
			a.traitementDeux();
		}
		
		if(choix == 2) {
			Menu restart = new Menu();
			restart.start();
		}
		
		if(choix == 3) {
			System.exit(0);
		}
		
	}
	
}

