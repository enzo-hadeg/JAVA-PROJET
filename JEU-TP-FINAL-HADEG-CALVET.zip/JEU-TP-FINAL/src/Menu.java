import java.util.Scanner;



public class Menu {
	
	public Menu() {
		
	}
	
	public void start() {
		System.out.println("Devinez le nombre(tapez 1)");
		System.out.println("Faites devinez � l'ordinateur(tapez 2)");
		
		
		
		Scanner in = new Scanner(System.in);	
		int choix = 0;
		
		choix = in.nextInt() ;
		
		
		while(choix !=1 && choix != 2 ) {
			choix =in.nextInt();
		}
		
		if(choix == 1) {
			
			NombreM a = new NombreM();
			a.traitement();
			
		}
		
		if(choix == 2) {



			System.out.println("Ouais donne moi un nombre a 4 chiffres");

			Scanner ina = new Scanner(System.in);

			int chiffre = ina.nextInt();



			NombreM a = new NombreM(chiffre);

			
			a.traitementDeux();


		}
	}
}
